def payment_aaa():
    print("this is payment details")